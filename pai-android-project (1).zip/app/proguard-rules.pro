# Keep Retrofit data models
-keepclassmembers class * {
    @com.google.gson.annotations.SerializedName <fields>;
}
-keep class com.pai.assistant.data.model.** { *; }

# OkHttp & Retrofit rules
-dontwarn okhttp3.**
-dontwarn retrofit2.**
