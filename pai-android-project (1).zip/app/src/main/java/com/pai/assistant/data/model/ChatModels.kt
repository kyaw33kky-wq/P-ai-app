package com.pai.assistant.data.model

import com.google.gson.annotations.SerializedName

data class MessagePayload(
    @SerializedName("role") val role: String,
    @SerializedName("content") val content: String
)

data class ChatRequest(
    @SerializedName("messages") val messages: List<MessagePayload>,
    @SerializedName("language") val language: String
)

data class ChatResponse(
    @SerializedName("reply") val reply: String,
    @SerializedName("error") val error: String? = null
)

data class UiChatMessage(
    val id: String,
    val role: String, // "user" or "assistant"
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
)
