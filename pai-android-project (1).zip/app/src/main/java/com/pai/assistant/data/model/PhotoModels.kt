package com.pai.assistant.data.model

import com.google.gson.annotations.SerializedName

data class PhotoEditRequest(
    @SerializedName("image") val image: String,
    @SerializedName("prompt") val prompt: String,
    @SerializedName("language") val language: String
)

data class FilterParams(
    @SerializedName("brightness") val brightness: Float? = null,
    @SerializedName("contrast") val contrast: Float? = null,
    @SerializedName("saturation") val saturation: Float? = null,
    @SerializedName("sepia") val sepia: Float? = null,
    @SerializedName("hueRotate") val hueRotate: Float? = null,
    @SerializedName("tintColor") val tintColor: String? = null,
    @SerializedName("tintOpacity") val tintOpacity: Float? = null,
    @SerializedName("snowEffect") val snowEffect: Boolean? = null
)

data class EditPlan(
    @SerializedName("presetType") val presetType: String,
    @SerializedName("filters") val filters: FilterParams?,
    @SerializedName("summary") val summary: String?
)

data class PhotoEditResponse(
    @SerializedName("success") val success: Boolean,
    @SerializedName("source") val source: String?,
    @SerializedName("editedImage") val editedImage: String?,
    @SerializedName("editPlan") val editPlan: EditPlan?,
    @SerializedName("description") val description: String?,
    @SerializedName("error") val error: String?
)
