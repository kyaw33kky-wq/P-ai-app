package com.pai.assistant.ui.theme

import androidx.compose.ui.graphics.Color

val BgDark = Color(0xFF090B10)
val SurfaceDark = Color(0xFF111520)
val HeaderDark = Color(0xFF0D1017)
val CardBorder = Color(0xFF1E293B)

val CyanAccent = Color(0xFF22D3EE)
val CyanGlow = Color(0xFF06B6D4)
val IndigoAccent = Color(0xFF6366F1)
val VioletAccent = Color(0xFF8B5CF6)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val UserBubble = Color(0xFF0284C7)
val AssistantBubble = Color(0xFF161B26)
val ErrorColor = Color(0xFFEF4444)
val SuccessColor = Color(0xFF10B981)
