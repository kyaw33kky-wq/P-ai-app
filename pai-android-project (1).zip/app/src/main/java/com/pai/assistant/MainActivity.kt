package com.pai.assistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pai.assistant.ui.screens.AboutScreen
import com.pai.assistant.ui.screens.ChatScreen
import com.pai.assistant.ui.screens.PhotoEditScreen
import com.pai.assistant.ui.theme.*
import com.pai.assistant.viewmodel.PaiViewModel

enum class ScreenTab {
    CHAT, PHOTO, ABOUT
}

class MainActivity : ComponentActivity() {
    private val viewModel: PaiViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PAiTheme {
                MainAppContent(viewModel)
            }
        }
    }
}

@Composable
fun MainAppContent(viewModel: PaiViewModel) {
    var selectedTab by remember { mutableStateOf(ScreenTab.CHAT) }

    val language by viewModel.language.collectAsState()
    val chatMessages by viewModel.chatMessages.collectAsState()
    val isChatLoading by viewModel.isChatLoading.collectAsState()

    val originalImage by viewModel.originalImageBase64.collectAsState()
    val editedImage by viewModel.editedImageUrl.collectAsState()
    val isPhotoLoading by viewModel.isPhotoLoading.collectAsState()
    val photoSummary by viewModel.photoEditSummary.collectAsState()
    val sliderPosition by viewModel.sliderPosition.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "P-Ai",
                            style = MaterialTheme.typography.titleLarge,
                            color = CyanAccent
                        )
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = HeaderDark
                        ) {
                            Text(
                                text = "PRO",
                                fontSize = 9.sp,
                                color = CyanAccent,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                    }
                },
                actions = {
                    if (selectedTab == ScreenTab.CHAT) {
                        IconButton(onClick = { viewModel.clearChat() }) {
                            Icon(
                                imageVector = Icons.Default.DeleteOutline,
                                contentDescription = "Clear Chat",
                                tint = TextSecondary
                            )
                        }
                    }

                    // Language Toggle Switch
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = SurfaceDark,
                        border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .clickable { viewModel.toggleLanguage() }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Language,
                                contentDescription = "Language",
                                tint = CyanAccent,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = if (language == "my") "🇲🇲 မြန်မာ" else "🇬🇧 EN",
                                fontSize = 12.sp,
                                color = TextPrimary
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = HeaderDark
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = HeaderDark,
                contentColor = TextPrimary
            ) {
                NavigationBarItem(
                    selected = selectedTab == ScreenTab.CHAT,
                    onClick = { selectedTab = ScreenTab.CHAT },
                    icon = { Icon(Icons.Default.ChatBubbleOutline, contentDescription = "Chat") },
                    label = { Text(if (language == "my") "စကားပြော" else "Chat", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = CyanAccent,
                        selectedTextColor = CyanAccent,
                        indicatorColor = SurfaceDark
                    )
                )

                NavigationBarItem(
                    selected = selectedTab == ScreenTab.PHOTO,
                    onClick = { selectedTab = ScreenTab.PHOTO },
                    icon = { Icon(Icons.Default.AutoFixHigh, contentDescription = "Photo Edit") },
                    label = { Text(if (language == "my") "ပုံပြင်ဆင်" else "Photo Edit", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = CyanAccent,
                        selectedTextColor = CyanAccent,
                        indicatorColor = SurfaceDark
                    )
                )

                NavigationBarItem(
                    selected = selectedTab == ScreenTab.ABOUT,
                    onClick = { selectedTab = ScreenTab.ABOUT },
                    icon = { Icon(Icons.Default.Info, contentDescription = "About") },
                    label = { Text(if (language == "my") "အကြောင်း" else "About", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = CyanAccent,
                        selectedTextColor = CyanAccent,
                        indicatorColor = SurfaceDark
                    )
                )
            }
        },
        containerColor = BgDark
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                ScreenTab.CHAT -> ChatScreen(
                    messages = chatMessages,
                    isLoading = isChatLoading,
                    language = language,
                    onSendMessage = { viewModel.sendMessage(it) }
                )
                ScreenTab.PHOTO -> PhotoEditScreen(
                    originalImageBase64 = originalImage,
                    editedImageUrl = editedImage,
                    isLoading = isPhotoLoading,
                    summary = photoSummary,
                    sliderPosition = sliderPosition,
                    language = language,
                    onImageSelected = { viewModel.setOriginalImage(it) },
                    onPromptSubmit = { viewModel.requestPhotoEdit(it) },
                    onSliderChange = { viewModel.setSliderPosition(it) }
                )
                ScreenTab.ABOUT -> AboutScreen(language = language)
            }
        }
    }
}
