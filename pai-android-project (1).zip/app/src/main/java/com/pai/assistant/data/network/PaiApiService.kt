package com.pai.assistant.data.network

import com.pai.assistant.BuildConfig
import com.pai.assistant.data.model.ChatRequest
import com.pai.assistant.data.model.ChatResponse
import com.pai.assistant.data.model.PhotoEditRequest
import com.pai.assistant.data.model.PhotoEditResponse
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import java.util.concurrent.TimeUnit

interface PaiApiService {
    @POST("api/chat")
    suspend fun sendChat(@Body request: ChatRequest): ChatResponse

    @POST("api/edit-photo")
    suspend fun editPhoto(@Body request: PhotoEditRequest): PhotoEditResponse

    companion object {
        fun create(): PaiApiService {
            val logging = HttpLoggingInterceptor().apply {
                level = if (BuildConfig.DEBUG) HttpLoggingInterceptor.Level.BODY else HttpLoggingInterceptor.Level.NONE
            }

            val client = OkHttpClient.Builder()
                .connectTimeout(60, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS)
                .writeTimeout(60, TimeUnit.SECONDS)
                .addInterceptor(logging)
                .build()

            val baseUrl = BuildConfig.BASE_URL

            return Retrofit.Builder()
                .baseUrl(baseUrl)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(PaiApiService::class.java)
        }
    }
}
