package com.pai.assistant.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.pai.assistant.data.model.ChatRequest
import com.pai.assistant.data.model.MessagePayload
import com.pai.assistant.data.model.PhotoEditRequest
import com.pai.assistant.data.model.UiChatMessage
import com.pai.assistant.data.network.PaiApiService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class PaiViewModel : ViewModel() {
    private val api = PaiApiService.create()

    private val _language = MutableStateFlow("my")
    val language: StateFlow<String> = _language.asStateFlow()

    private val _chatMessages = MutableStateFlow<List<UiChatMessage>>(emptyList())
    val chatMessages: StateFlow<List<UiChatMessage>> = _chatMessages.asStateFlow()

    private val _isChatLoading = MutableStateFlow(false)
    val isChatLoading: StateFlow<Boolean> = _isChatLoading.asStateFlow()

    // Photo Edit States
    private val _originalImageBase64 = MutableStateFlow<String?>(null)
    val originalImageBase64: StateFlow<String?> = _originalImageBase64.asStateFlow()

    private val _editedImageUrl = MutableStateFlow<String?>(null)
    val editedImageUrl: StateFlow<String?> = _editedImageUrl.asStateFlow()

    private val _isPhotoLoading = MutableStateFlow(false)
    val isPhotoLoading: StateFlow<Boolean> = _isPhotoLoading.asStateFlow()

    private val _photoEditSummary = MutableStateFlow<String?>(null)
    val photoEditSummary: StateFlow<String?> = _photoEditSummary.asStateFlow()

    private val _sliderPosition = MutableStateFlow(0.5f)
    val sliderPosition: StateFlow<Float> = _sliderPosition.asStateFlow()

    init {
        resetChatWelcome()
    }

    fun toggleLanguage() {
        val nextLang = if (_language.value == "my") "en" else "my"
        _language.value = nextLang
        if (_chatMessages.value.size <= 1) {
            resetChatWelcome()
        }
    }

    private fun resetChatWelcome() {
        val welcomeText = if (_language.value == "my") {
            "မင်္ဂလာပါခင်ဗျာ! ကျွန်တော်ကတော့ သင့်ရဲ့ ကိုယ်ပိုင် စမတ် AI အဖော်မွန် P-Ai (ပီအိုင်) ဖြစ်ပါတယ်။ သိလိုသမျှ မေးမြန်းနိုင်သလို ဓာတ်ပုံတွေကိုလည်း လိုသလို ပြင်ဆင်ခိုင်းနိုင်ပါတယ်ခင်ဗျာ။"
        } else {
            "Hello! I am your personal smart AI assistant P-Ai. Feel free to ask questions or edit photos with creative prompts!"
        }
        _chatMessages.value = listOf(
            UiChatMessage(
                id = "welcome",
                role = "assistant",
                content = welcomeText
            )
        )
    }

    fun clearChat() {
        resetChatWelcome()
    }

    fun sendMessage(text: String) {
        if (text.isBlank()) return

        val userMessage = UiChatMessage(
            id = "user_${System.currentTimeMillis()}",
            role = "user",
            content = text
        )

        val updatedList = _chatMessages.value + userMessage
        _chatMessages.value = updatedList
        _isChatLoading.value = true

        viewModelScope.launch {
            try {
                val payload = updatedList.map {
                    MessagePayload(role = it.role, content = it.content)
                }
                val response = api.sendChat(ChatRequest(messages = payload, language = _language.value))
                val replyContent = response.reply.ifBlank {
                    if (_language.value == "my") "တောင်းပန်ပါတယ်ခင်ဗျာ၊ အဖြေမရရှိခဲ့ပါ။" else "I apologize, but no answer could be retrieved."
                }
                _chatMessages.value = _chatMessages.value + UiChatMessage(
                    id = "assistant_${System.currentTimeMillis()}",
                    role = "assistant",
                    content = replyContent
                )
            } catch (e: Exception) {
                val errorMsg = if (_language.value == "my") {
                    "ချိတ်ဆက်မှု ပြဿနာတစ်ခု ဖြစ်ပွားခဲ့ပါသည်။ ကျေးဇူးပြု၍ ထပ်မံမေးမြန်းပေးပါခင်ဗျာ။"
                } else {
                    "A connection issue occurred. Please ask again in a moment."
                }
                _chatMessages.value = _chatMessages.value + UiChatMessage(
                    id = "error_${System.currentTimeMillis()}",
                    role = "assistant",
                    content = errorMsg
                )
            } finally {
                _isChatLoading.value = false
            }
        }
    }

    fun setOriginalImage(base64: String) {
        _originalImageBase64.value = base64
        _editedImageUrl.value = null
        _photoEditSummary.value = null
        _sliderPosition.value = 0.5f
    }

    fun setSliderPosition(pos: Float) {
        _sliderPosition.value = pos.coerceIn(0f, 1f)
    }

    fun requestPhotoEdit(prompt: String) {
        val image = _originalImageBase64.value ?: return
        if (prompt.isBlank()) return

        _isPhotoLoading.value = true
        _photoEditSummary.value = null

        viewModelScope.launch {
            try {
                val response = api.editPhoto(
                    PhotoEditRequest(
                        image = image,
                        prompt = prompt,
                        language = _language.value
                    )
                )

                if (response.success) {
                    _editedImageUrl.value = response.editedImage ?: image
                    _photoEditSummary.value = response.description ?: response.editPlan?.summary
                } else {
                    _photoEditSummary.value = response.description ?: "Could not process photo edit."
                }
            } catch (e: Exception) {
                _photoEditSummary.value = if (_language.value == "my") {
                    "ပုံပြင်ဆင်ရာတွင် အဆင်မပြေမှု ဖြစ်ပွားခဲ့ပါသည်။"
                } else {
                    "An error occurred while editing the photo."
                }
            } finally {
                _isPhotoLoading.value = false
            }
        }
    }
}
