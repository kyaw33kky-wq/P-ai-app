package com.pai.assistant.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pai.assistant.ui.theme.*

@Composable
fun AboutScreen(language: String) {
    val scrollState = rememberScrollState()

    val features = if (language == "my") {
        listOf(
            "မြန်မာ နှင့် အင်္ဂလိပ် နှစ်ဘာသာစလုံးကို သဘာဝကျကျ အပြန်အလှန် ဆွေးနွေးနိုင်ခြင်း",
            "Gemini 3.8 Flash အဆင့်မြင့် AI စနစ်ဖြင့် တိကျမြန်ဆန်စွာ ဖြေကြားပေးခြင်း",
            "စမတ် ဓာတ်ပုံ တည်းဖြတ်မှု (ဆောင်းရာသီ၊ အန်နီမေး၊ အဖြူအမည်း၊ အရည်အသွေးမြှင့်)",
            "Before / After ဓာတ်ပုံ နှိုင်းယှဉ်စစ်ဆေးမှု Slider စနစ်",
            "ဖုန်းတွင်း Browser bar မပါဘဲ Native Android UI ဖြင့် အသုံးပြုနိုင်ခြင်း"
        )
    } else {
        listOf(
            "Natural bilingual AI conversation in Burmese and English",
            "Powered by state-of-the-art Gemini 3.8 Flash model",
            "Smart AI photo styling (Winter, Anime, Vintage B&W, Enhancements)",
            "Interactive Before / After split comparison slider",
            "Standalone native Android experience with zero browser address bar"
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDark)
            .verticalScroll(scrollState)
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // App Title
        Text(
            text = "P-Ai",
            fontSize = 28.sp,
            style = MaterialTheme.typography.headlineMedium,
            color = CyanAccent
        )

        Text(
            text = if (language == "my") "မြန်မာ-အင်္ဂလိပ် နှစ်ဘာသာသုံး စမတ် AI အဖော်မွန်" else "Bilingual Smart AI Companion",
            fontSize = 13.sp,
            color = TextSecondary
        )

        // Capabilities Card
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceDark),
            border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = if (language == "my") "အဓိက စွမ်းဆောင်ရည်များ" else "Key Capabilities",
                    fontSize = 14.sp,
                    color = CyanAccent
                )

                features.forEach { feat ->
                    Row(
                        verticalAlignment = Alignment.Top,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = CyanAccent,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = feat,
                            fontSize = 13.sp,
                            color = TextPrimary,
                            lineHeight = 20.sp
                        )
                    }
                }
            }
        }

        // Security Card
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceDark),
            border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = null,
                    tint = SuccessColor,
                    modifier = Modifier.size(24.dp)
                )
                Text(
                    text = if (language == "my")
                        "လုံခြုံစိတ်ချရသော Server-Side Gemini API Proxy ဖြင့် လျှို့ဝှက်ချက်များကို အပြည့်အဝ ထိန်းသိမ်းထားပါသည်။"
                    else
                        "Protected by secure server-side API proxy, keeping user secrets safe.",
                    fontSize = 12.sp,
                    color = TextSecondary,
                    lineHeight = 18.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "P-Ai Native Android Edition v1.0.0",
            fontSize = 11.sp,
            color = TextMuted
        )
    }
}
