package com.pai.assistant.ui.screens

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.pai.assistant.ui.theme.*
import java.io.ByteArrayOutputStream
import java.io.InputStream

fun saveImageToGallery(context: Context, base64OrUrl: String, language: String) {
    try {
        val base64Data = if (base64OrUrl.contains(",")) base64OrUrl.substringAfter(",") else base64OrUrl
        val bytes = Base64.decode(base64Data, Base64.DEFAULT)
        val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        if (bitmap != null) {
            val filename = "PAi_Edited_${System.currentTimeMillis()}.jpg"
            val contentValues = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
                put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/P-Ai")
                }
            }
            val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
            uri?.let {
                context.contentResolver.openOutputStream(it)?.use { stream ->
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 95, stream)
                }
                val msg = if (language == "my") "ဓာတ်ပုံကို ဖုန်း Gallery ထဲသို့ သိမ်းဆည်းပြီးပါပြီ!" else "Photo saved to Gallery!"
                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            }
        }
    } catch (e: Exception) {
        val err = if (language == "my") "သိမ်းဆည်းရာတွင် အဆင်မပြေပါ" else "Failed to save photo"
        Toast.makeText(context, err, Toast.LENGTH_SHORT).show()
    }
}

@Composable
fun PhotoEditScreen(
    originalImageBase64: String?,
    editedImageUrl: String?,
    isLoading: Boolean,
    summary: String?,
    sliderPosition: Float,
    language: String,
    onImageSelected: (String) -> Unit,
    onPromptSubmit: (String) -> Unit,
    onSliderChange: (Float) -> Unit
) {
    val context = LocalContext.current
    var customPrompt by remember { mutableStateOf("") }
    val scrollState = rememberScrollState()

    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            val inputStream: InputStream? = context.contentResolver.openInputStream(it)
            val bitmap = BitmapFactory.decodeStream(inputStream)
            if (bitmap != null) {
                val outputStream = ByteArrayOutputStream()
                bitmap.compress(Bitmap.CompressFormat.JPEG, 85, outputStream)
                val bytes = outputStream.toByteArray()
                val base64 = "data:image/jpeg;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP)
                onImageSelected(base64)
            }
        }
    }

    val presets = if (language == "my") {
        listOf(
            "ဆောင်းရာသီ နှင်းစတိုင်" to "make it winter with cold snow ambiance",
            "အရည်အသွေး မြှင့်တင်ရန်" to "enhance photo quality and sharpness",
            "နောက်ခံ ပြောင်းလဲရန်" to "change the background to scenic sunset",
            "ဂန္တဝင် အဖြူအမည်း" to "vintage black and white film style",
            "အန်နီမေး ကာတွန်းစတိုင်" to "anime cartoon illustration style"
        )
    } else {
        listOf(
            "Make it Winter" to "make it winter with cold snow ambiance",
            "Enhance Quality" to "enhance photo quality and sharpness",
            "Change Background" to "change the background to scenic sunset",
            "Vintage B&W" to "vintage black and white film style",
            "Anime Style" to "anime cartoon illustration style"
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgDark)
            .verticalScroll(scrollState)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Upload Button
        Button(
            onClick = { imagePickerLauncher.launch("image/*") },
            colors = ButtonDefaults.buttonColors(
                containerColor = SurfaceDark
            ),
            border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(
                imageVector = Icons.Default.AddPhotoAlternate,
                contentDescription = "Upload",
                tint = CyanAccent,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (language == "my") "ဓာတ်ပုံ အသစ်ရွေးချယ်မည်" else "Choose Photo from Gallery",
                color = TextPrimary,
                fontSize = 14.sp
            )
        }

        // Preview Comparison Area
        if (originalImageBase64 != null) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(Unit) {
                            detectDragGestures { change, _ ->
                                change.consume()
                                val newPos = change.position.x / size.width
                                onSliderChange(newPos)
                            }
                        }
                ) {
                    // Original Image
                    AsyncImage(
                        model = originalImageBase64,
                        contentDescription = "Original",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )

                    // Edited Image Overlay if available
                    if (editedImageUrl != null) {
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .fillMaxWidth(sliderPosition)
                                .clip(RoundedCornerShape(0.dp))
                        ) {
                            AsyncImage(
                                model = editedImageUrl,
                                contentDescription = "Edited",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        }

                        // Divider line
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .width(2.dp)
                                .offset(x = (300 * sliderPosition).dp)
                                .background(Color.White)
                        )
                    }

                    // Before / After Badges
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color.Black.copy(alpha = 0.6f)
                        ) {
                            Text(
                                text = if (language == "my") "မူရင်း" else "Original",
                                color = Color.White,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }

                        if (editedImageUrl != null) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = CyanAccent.copy(alpha = 0.8f)
                            ) {
                                Text(
                                    text = if (language == "my") "ပြင်ဆင်ပြီး" else "Edited",
                                    color = BgDark,
                                    fontSize = 11.sp,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Download Edited Image Button
            if (editedImageUrl != null) {
                Button(
                    onClick = { saveImageToGallery(context, editedImageUrl, language) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyanAccent
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = Icons.Default.Download,
                        contentDescription = "Download",
                        tint = BgDark,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (language == "my") "ပြင်ဆင်ပြီး ဓာတ်ပုံကို ဖုန်းထဲသိမ်းမည် (Download)" else "Save Edited Photo to Gallery",
                        color = BgDark,
                        fontSize = 13.sp
                    )
                }
            }
        }

        // Summary Text
        if (!summary.isNullOrBlank()) {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = SurfaceDark,
                border = androidx.compose.foundation.BorderStroke(1.dp, CyanAccent.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = summary,
                    color = TextPrimary,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(12.dp)
                )
            }
        }

        // Preset Prompt Buttons
        Text(
            text = if (language == "my") "အမြန်ပြင်ဆင်နည်းများ" else "Quick Style Presets",
            color = TextSecondary,
            fontSize = 12.sp,
            modifier = Modifier.fillMaxWidth()
        )

        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            presets.forEach { (label, prompt) ->
                Button(
                    onClick = { onPromptSubmit(prompt) },
                    enabled = originalImageBase64 != null && !isLoading,
                    colors = ButtonDefaults.buttonColors(containerColor = SurfaceDark),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CardBorder),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoFixHigh,
                        contentDescription = null,
                        tint = CyanAccent,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = label,
                        color = TextPrimary,
                        fontSize = 13.sp
                    )
                }
            }
        }

        // Custom Prompt Input
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TextField(
                value = customPrompt,
                onValueChange = { customPrompt = it },
                placeholder = {
                    Text(
                        text = if (language == "my") "ဥပမာ - နှင်းကျနေသော ပုံစံပြောင်းပေးပါ" else "e.g., add rainy reflection",
                        color = TextMuted,
                        fontSize = 13.sp
                    )
                },
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(14.dp)),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = SurfaceDark,
                    unfocusedContainerColor = SurfaceDark,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )

            Button(
                onClick = {
                    if (customPrompt.isNotBlank()) {
                        onPromptSubmit(customPrompt)
                        customPrompt = ""
                    }
                },
                enabled = originalImageBase64 != null && customPrompt.isNotBlank() && !isLoading,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = CyanAccent
                )
            ) {
                Text(
                    text = if (language == "my") "ပြင်ဆင်" else "Apply",
                    color = BgDark,
                    fontSize = 13.sp
                )
            }
        }
    }
}
