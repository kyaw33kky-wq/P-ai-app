# P-Ai Native Android (Jetpack Compose) — Play Store & APK Guide

This directory contains the full, production-ready **Native Android** application for **P-Ai**, built with **Kotlin** and **Jetpack Compose**.

---

## 📱 Features Included
1. **Zero Browser Address Bar:** Runs as an authentic standalone Android application.
2. **Material 3 Dark Theme:** Matching P-Ai's obsidian, cyan, and indigo glowing aesthetics.
3. **Bilingual Support:** Myanmar (Burmese Unicode) and English language toggle.
4. **AI Chat Interface:** Multi-turn conversational UI with prompt suggestions and loading indicators.
5. **Photo Edit Studio:** Gallery image picker, style presets (Winter, Anime, B&W, Enhancements), and touch Before/After comparison slider.
6. **Secure Backend API:** Communicates directly with the secure P-Ai backend without exposing secrets on the client device.

---

## 🛠️ How to Build & Run in Android Studio

1. **Open in Android Studio:**
   - Launch Android Studio (Ladybug or later recommended).
   - Select **Open** and choose the `android` folder.
   - Wait for Gradle to complete sync.

2. **Run on Emulator / Physical Device:**
   - Connect your Android phone via USB with USB Debugging enabled.
   - Click **Run 'app'** (`Shift + F10`).
   - The app installs and runs natively on your phone.

---

## 📦 How to Generate APK for Direct Phone Installation

To test or distribute directly outside the Play Store:
1. In Android Studio, go to **Build** > **Build Bundle(s) / APK(s)** > **Build APK(s)**.
2. Android Studio outputs the `.apk` file to:
   `android/app/build/outputs/apk/debug/app-debug.apk`
3. Copy this `.apk` to any Android phone and tap to install!

---

## 🚀 Preparing for Google Play Store Release

### Step 1: Generate Release Keystore
In Android Studio:
1. Go to **Build** > **Generate Signed Bundle / APK...**
2. Choose **Android App Bundle (.aab)** (required by Google Play).
3. Under **Key store path**, click **Create new...**
4. Specify keystore password, alias name (`pai_release_key`), and validity (e.g., 25 years).
5. Save the generated `.jks` file securely.

### Step 2: Build Release AAB
1. Select the **release** build variant.
2. Click **Create**.
3. The resulting `.aab` file will be generated in `app/release/app-release.aab`.

### Step 3: Google Play Console Internal Testing
1. Log in to [Google Play Console](https://play.google.com/console).
2. Create a new app:
   - App Name: `P-Ai - Smart AI Assistant`
   - Default Language: `Burmese (my) - or English (en)`
   - App or Game: `App`
   - Free or Paid: `Free`
3. Under **Testing** > **Internal testing**, create a new release.
4. Upload `app-release.aab`.
5. Add internal tester email addresses (e.g. your Gmail).
6. Save and publish. Testers will receive an internal test link to download directly from the Google Play Store!
